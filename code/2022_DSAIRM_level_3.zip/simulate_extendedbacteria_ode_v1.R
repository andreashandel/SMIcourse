# This function simulates a bacteria infection with 2 strains of the bacteria
# It is based on the Extended Bacteria model of DSAIRM 
# (the simulate_extendedbacteria_ode.R code)
# This code further extends that model
# by including a second bacteria strain
# all following functions/R code files further extend the model
simulate_extendedbacteria_ode_v1 <- function(B1 = 100, 
                                             B2 = 100, 
                                             I = 1, 
                                             A = 1,
                                             g = 1, 
                                             Bmax = 1e+05, 
                                             dB = 0.5,
                                             kI1 = 1e-4, 
                                             kA1 = 1e-4,
                                             kI2 = 1e-4, 
                                             kA2 = 1e-4,
                                             rI = 1, 
                                             Imax = 1e5, 
                                             dI = 1,
                                             rA = 1, 
                                             h = 1e3, 
                                             dA = 0.1,
                                             tstart = 0, 
                                             tfinal = 100, 
                                             dt = 0.01)
{

  #Block of ODE equations for deSolve
  extendedbacteria_ode_fct <- function(t, y, parms)
  {
    with( as.list(c(y,parms)), { #lets us access variables and parameters stored in y and parms by name
    #StartODES
    
    #Bacteria : bacteria growth : bacteria death : immune response killing :
    dB1 = g*B1*(1-B1/Bmax) - dB*B1 - kI1*B1*I - kA1*B1*A 
    dB2 = g*B2*(1-B2/Bmax) - dB*B2 - kI2*B2*I - kA2*B2*A 
    
    #Innate Immune Response : innate response growth : innate response decay :
    dI = rI*(B1+B2)*(1-I/Imax) - dI*I

    #Adaptive Immune Response : adaptive response growth : adaptive response decay :
    #extra max statement ensures no negative values on log scale
    dA = rA*A*log(max(I,1))/(log(max(I,1)) + h) - dA*A

    #EndODES
    list(c(dB1,dB2,dI,dA))
    
  } ) } #close with statement, end ODE function code block



  #Main function code block
  timevec=seq(tstart,tfinal,by=dt)
  vars = c(B1 = B1, B2 = B2, I = I, A = A)
  pars = c(g = g, Bmax = Bmax, dB =dB, kI1 = kI1, kA1 = kA1, kI2 = kI2, kA2 = kA2, 
           rI = rI, Imax = Imax, dI = dI, 
           rA = rA, h = h, dA = dA)
  odeout = deSolve::ode(y = vars, parms = pars, times = timevec,  func = extendedbacteria_ode_fct, atol = 1e-12, rtol = 1e-12, method = "vode")
  result <- list()
  result$ts <- as.data.frame(odeout)
  return(result)
}
