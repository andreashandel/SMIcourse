###########
# A script that calls a sequence of models
# each model is based on the previous one and contains additional details
# the first model is an extension of the extended bacteria model in DSAIRM
# (the simulate_extendedbacteria_ode.R code)
# This script assumes that the working directory contains the R scripts which
# write the simulation functions, hence the relative paths. 
# If there are errors
# when sourcing the other scripts, check the given filepaths: 
# this script and the others need to be in the same folder.
###########

# loading DSAIRM so we can use generate_ggplot()
library(DSAIRM)

###########
# Model 1
# includes 2 bacteria strains
###########
# load first model variant
source('simulate_extendedbacteria_ode_v1.R')
res1 <- simulate_extendedbacteria_ode_v1(kA2 = 1e-5, 
                                         kI2 = 1e-5)
generate_ggplot(list(res1))

# same model with different settings
res1b <- simulate_extendedbacteria_ode_v1(kA2 = 1e-5, 
                                          kI2 = 1e-5, 
                                          rA = 3, 
                                          h = 1e2)
res1b$yscale = "log10"
generate_ggplot(list(res1b))


###########
# Model 2
# includes 2 innate responses
###########
source('simulate_extendedbacteria_ode_v2.R')
res2 <- simulate_extendedbacteria_ode_v2(kA2 = 5e-5, 
                                         kI2 = 5e-5, 
                                         rA = 3, 
                                         h = 1e2, 
                                         rF = 2, 
                                         Fmax = 1e3)
res2$yscale = "log10"
generate_ggplot(list(res2))


###########
# Model 3
# includes de-novo generation of second bacteria strain
###########
source('simulate_extendedbacteria_ode_v3.R')
res3 <- simulate_extendedbacteria_ode_v3(kA2 = 5e-5, 
                                         kI2 = 5e-5, 
                                         rA = 0, 
                                         h = 1e2, 
                                         rF = 2, 
                                         Fmax = 1e3, 
                                         mu = 1e-6)
res3$yscale = "log10"
generate_ggplot(list(res3))


###########
# Model 4
# includes drug
###########
source('simulate_extendedbacteria_ode_v4.R')
res4 <- simulate_extendedbacteria_ode_v4(kA2 = 5e-5, 
                                         kI2 = 5e-5, 
                                         rA = 0, 
                                         h = 1e2, 
                                         rF = 2, 
                                         Fmax = 1e3,
                                         mu = 1e-6, 
                                         kD1 = 1e-3, 
                                         kD2 = 1e-3)
res4$yscale = "log10"
generate_ggplot(list(res4))

