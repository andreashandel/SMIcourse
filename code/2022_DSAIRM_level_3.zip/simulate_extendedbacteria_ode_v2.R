# This function is based on model variant 1, and includes an additional
# innate response component (labelled F)

simulate_extendedbacteria_ode_v2 <- function(B1 = 100, 
                                             B2 = 100, 
                                             I = 1, 
                                             A = 1,
                                             g = 1, 
                                             Bmax = 1e+05, 
                                             dB = 0.5,
                                             kI1 = 1e-4, 
                                             kA1 = 1e-4,
                                             kI2 = 1e-4, 
                                             kA2 = 1e-4,
                                             rI = 1, 
                                             Imax = 1e5, 
                                             dI = 1,
                                             rA = 1, 
                                             h = 1e3, 
                                             dA = 0.1,
                                             rF = 1, 
                                             Fmax = 1e5, 
                                             dF = 1,
                                             kF1 = 1e-4, 
                                             kF2 = 1e-4,
                                             tstart = 0, 
                                             tfinal = 100, 
                                             dt = 0.01)
{

  #Block of ODE equations for deSolve
  extendedbacteria_ode_fct <- function(t, y, parms)
  {
    with( as.list(c(y,parms)), { #lets us access variables and parameters stored in y and parms by name
    #StartODES
    
    #Bacteria : bacteria growth : bacteria death : immune response killing :
    dB1 = g*B1*(1-B1/Bmax) - dB*B1 - kI1*B1*I - kA1*B1*A - kF1*B1*F
    dB2 = g*B2*(1-B2/Bmax) - dB*B2 - kI2*B2*I - kA2*B2*A - kF2*B2*F
    
    #Innate Immune Response : innate response growth : innate response decay :
    dI = rI*(B1+B2)*(1-I/Imax) - dI*I
    dF = rF*(B1+B2)*(1-F/Fmax) - dF*F
    
    
    #Adaptive Immune Response : adaptive response growth : adaptive response decay :
    #extra max statement ensures no negative values on log scale
    
    dA = rA*A*log(max(F,1))/(log(max(F,1)) + h) - dA*A
    
    
    #EndODES
    list(c(dB1,dB2,dI,dF,dA))
    
  } ) } #close with statement, end ODE function code block



  #Main function code block
  timevec=seq(tstart,tfinal,by=dt)
  vars = c(B1 = B1, B2 = B2, I = I, F = F, A = A)
  pars = c(g = g, Bmax = Bmax, dB =dB, kI1 = kI1, kA1 = kA1, kI2 = kI2, kA2 = kA2, 
           rI = rI, Imax = Imax, dI = dI, 
           rF = rF, Fmax = Fmax, dF = dF, kF1 = kF1, kF2 = kF2, 
           rA = rA, h = h, dA = dA)
  odeout = deSolve::ode(y = vars, parms = pars, times = timevec,  func = extendedbacteria_ode_fct, atol = 1e-12, rtol = 1e-12, method = "vode")
  result <- list()
  result$ts <- as.data.frame(odeout)
  return(result)
}
